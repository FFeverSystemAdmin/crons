<?php
    class config{
        public static $USER_NAME = "support@ffever.in";
        public static $HASH_CODE = "1afae0a7a69a2b679f1d5a2e62c406384cb7a2621734a8b89bcfb3ff50d85196";
        public static $API_KEY = "F6jSDrJpAgc-62qMxN2syOI641CNB3Kujn1SHkhOFg";
        public static $SENDER = "TMFCPL";
        public static $MESSAGE = "#* 1234 SERVER \"173.249.50.121\"05001#";
    }
?>